<?php

namespace Modules\SIGAC\Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Modules\SICA\Entities\App;
use Modules\SICA\Entities\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Consultar aplicación SIGAC para registrar los roles
        $app = App::where('name', 'SIGAC')->firstOrFail();

        // Registrar o actualizar rol de SUPERADMINISTRADOR
        $role_super_admin = Role::firstOrCreate(['slug' => 'superadmin'], [
            'name' => 'Super Administrador',
            'description' => 'Rol Superadministrador de SICEFA',
            'description_english' => 'Role Super administrator of SICEFA',
            'full_access' => 'Si',
            'app_id' => $app->id
        ]);

        // Registrar o actualizar rol de Coordinador Académico
        $rol_academic_coordinator = Role::firstOrCreate(['slug' => 'sigac.academic_coordinator'], [
            'name' => 'Coordinador Académico',
            'description' => 'Rol Coordinador Académico de la aplicación SIGAC',
            'description_english' => 'Role Academic Coordinator of the SIGAC application',
            'app_id' => $app->id
        ]);

        // Registrar o actualizar rol de Instructor
        $rol_instructor = Role::firstOrCreate(['slug' => 'sigac.instructor'], [
            'name' => 'Instructor',
            'description' => 'Rol Instructor de la aplicación SIGAC',
            'description_english' => 'Role Instructor of the SIGAC application',
            'app_id' => $app->id
        ]);

        // Registrar o actualizar rol de Bienestar
        $rol_wellness = Role::firstOrCreate(['slug' => 'sigac.wellbeing'], [
            'name' => 'Bienestar',
            'description' => 'Rol Bienestar de la aplicación SIGAC',
            'description_english' => 'Role Wellness of the SIGAC application',
            'app_id' => $app->id
        ]);

        // Registrar o actualizar rol de Aprendiz
        $rol_apprentice = Role::firstOrCreate(['slug' => 'sigac.apprentice'], [
            'name' => 'Aprendiz',
            'description' => 'Rol Aprendiz de la aplicación SIGAC',
            'description_english' => 'Role Apprentice of the SIGAC application',
            'app_id' => $app->id
        ]);

        // Registrar o actualizar rol de Aprendiz
        $rol_support = Role::firstOrCreate(['slug' => 'sigac.support'], [
            'name' => 'Apoyo',
            'description' => 'Rol Apoyo de la aplicación SIGAC',
            'description_english' => 'Role support of the SIGAC application',
            'app_id' => $app->id
        ]);


        $rol_tutor = Role::firstOrCreate(['slug' => 'sigac.tutor'], [
            'name' => 'Tutor',
            'description' => 'Rol Tutor de la aplicación SIGAC',
            'description_english' => 'Tutor Role of the SIGAC application',
            'app_id' => $app->id
        ]);

        // Registrar o actualizar rol del personal de seguridad
        $rol_security_personnel = Role::firstOrCreate(['slug' => 'sigac.security.personnel'], [
            'name' => 'Personal Seguridad',
            'description' => 'Rol del Personal Seguridad de la aplicacion SIGAC',
            'description_english' => 'Security Personnel Role of the SIGAC Application',
            'app_id' => $app->id
        ]);


    }
}
